package com.tjpu.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import com.tjpu.util.Common;
import com.tjpu.util.DBHelp;
import com.tjpu.util.FileHelp;

public class WeblogDao {
   public static int makeRandDataToDb() throws ParseException, SQLException {
	   int ret=0;
	   String str="";
       //Date p_date=Calendar.getInstance().getTime();
		Date p_date = Calendar.getInstance().getTime();
       Common com = new Common();
       
       //String ip_address="201.231.210.90";
       String ip_address="";
       int ipcnt=4;
       for (int i = 0; i < ipcnt; i++) {
    	    if (i==3) {  
	      	   ip_address=ip_address+com.getRand(253);
	        } else {
	          ip_address=ip_address+com.getRand(253)+".";
	 	    }	   
	   }
	   
      // System.out.println(ip_address);
       
       String access_time=com.getCurrentDate();
       int access_count=com.getRand(100);
       
		String p_sql="insert into log_20170621 (ip_address,access_time,access_count) values(";
		p_sql = p_sql+"'"+ip_address+"',";
		p_sql = p_sql+"'"+access_time+"',";
		p_sql = p_sql+access_count+")";
		
		//运行SQL
		ret=DBHelp.executeSQl(p_sql);
		if (ret>0) {
		 System.out.println("插入成功");		
		} else {
			 System.out.println("插入失败");		
					
		}
	   return ret;
}
   
/*随机数据写入文件*/
public static int makeRandDataToFile(int profix) throws ParseException {
	/*最高访问次数*/ 
	int ACCESS_COUNT=100;
		
	   int ret=0;
	   String str="";
    //Date p_date=Calendar.getInstance().getTime();
		Date p_date = Calendar.getInstance().getTime();
    Common com = new Common();
    
    //String ip_address="201.231.210.90";
    String ip_address="";
    int ipcnt=4;
    for (int i = 0; i < ipcnt; i++) {
 	    if (i==3) {  
	      	   ip_address=ip_address+com.getRand(253);
	        } else {
	          ip_address=ip_address+com.getRand(253)+".";
	 	    }	   
	   }
	   
    //System.out.println(ip_address);
    
    String access_time=com.getCurrentDate();
   int access_count=com.getRand(ACCESS_COUNT);
    
	//String p_sql="1,";
    String p_sql=profix+",";
	
	p_sql = p_sql+ip_address+",";
	p_sql = p_sql+access_time+",";
	p_sql = p_sql+access_count+"\r\n";
	
    String p_filename="log_"+com.getCurrentByDate()+".txt";		
   // System.out.println(p_filename);
    //写入文件
	ret=FileHelp.writeToFile(p_filename, p_sql);
		
	   return ret;
}
}