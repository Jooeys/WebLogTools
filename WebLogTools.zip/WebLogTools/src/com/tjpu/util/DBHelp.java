﻿package com.tjpu.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class DBHelp {
   /*�����ȡ��ѯ���*/
	public static ResultSet getResult(String p_sql,Object[] para) {
		ResultSet rs=null;
		Connection con;
		try {
			con = getConnection();
			//Statement stm=con.createStatement();
			
			PreparedStatement pstm=con.prepareStatement(p_sql);
			for (int i = 0; i < para.length; i++) {
				pstm.setObject(i+1, para[i]);
			}
			rs =pstm.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rs;
		
	}
	/*��ȡ��ѯ���*/
	public static ResultSet getResult(String p_sql) {
		ResultSet rs=null;
		Connection con;
		try {
			con = getConnection();
			Statement stm=con.createStatement();
			rs =stm.executeQuery(p_sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rs;
		
	}
	/*���ô洢���
	 * p_procname:�洢������
	 * para����������
	 * */
	public static int executeProc(String p_procname,Object[] para){
		int ret=-1;
		CallableStatement callStm;
	    String str_sql=" {call"+ p_procname+"}"; 
	    Connection con;
			try {
				con = getConnection();
				//callStm = con.prepareCall("{call p_add(?,?,?)}");
	        	//callStm = con.prepareCall("{?=call p_return(?,?)}");
	        	callStm = con.prepareCall(str_sql);
	        	for (int i = 0; i < para.length; i++) {
	        		callStm.setObject(i+2, para[i]);
				}
	    	 //�����������
	    	 callStm.registerOutParameter(1,Types.INTEGER);
	    	 callStm.execute();
	    	 ret=callStm.getInt(1);
	    	 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		return ret;
	}

	public static int executeSQl(String p_sql,Object[] para){
		   int ret=0;
		   Connection con;
		
			try {
				con = getConnection();
				PreparedStatement pstm=con.prepareStatement(p_sql);
				for (int i = 0; i < para.length; i++) {
					pstm.setObject(i+1, para[i]);
				}
				ret=pstm.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   return ret;
	   }
	
	public static int executeSQl(String p_sql) throws SQLException {
		int ret=0;
		Connection con=null;
		try {
			con = getConnection(); //获取链接
			Statement stm=con.createStatement();
			ret=stm.executeUpdate(p_sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (con!=null)
		con.close();
		
		
	    /*�ر���Դ*/
		return ret;
		
	}
	public static  Connection getConnection() throws SQLException {
	  String DB_DRIVER="com.mysql.jdbc.Driver"; 
	  //String DB_DRIVER=new FileHelp().getProperty("db","DB_DRIVER"); 
		  
	  String DB_HOST="192.168.56.129";
	  String DB_PORT="3306";
	  String DB_NAME="logdata";
	  String DB_USER_NAME="zhong";
	  String DB_PWD_NAME="31415926";
	  String DB_URL="jdbc:mysql://"; 
	  
	  Connection con =null ;
	  
	  try {
		Class.forName(DB_DRIVER);
		con = DriverManager.getConnection(DB_URL+DB_HOST+":"+DB_PORT+"/"+DB_NAME,DB_USER_NAME,DB_PWD_NAME);
	  } catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	  }
	   
	   return con;
	   
   }
	public static  void  Close(Connection cn,Statement st,ResultSet rs) {
		
		if (rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (cn!=null) {
			try {
				cn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (st!=null) {
			try {
				st.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
