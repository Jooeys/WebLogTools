package com.tjpu.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Common {
  
public static int getRand(int value) {
	  int rand=-1;
	  Random rd =new Random();
	  
	  rand=rd.nextInt(value);
	  
	  return rand;
	  
  }

public static String getCurrentByDate() throws ParseException {
	  String str_date="";
	  Date  date = Calendar.getInstance().getTime();
	  str_date=getformatByDate(date);
	  
	  return str_date;
}

public static String getCurrentDate() throws ParseException {
	  String str_date="";
	  Date  date = Calendar.getInstance().getTime();
	  //str_date+=date.getYear()+"-";
	  //str_date+=date.getMonth()+"-";
	  //str_date+=date.getDay()+"-";
      	
	  str_date=getformatDate(date);
	  
	  return str_date;
	  
  }

public static  String getformatByDate(Date date)throws ParseException{
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
   return sdf.format(date);
}

public static  String getformatDate(Date date)throws ParseException{
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
     return sdf.format(date);
 }
 
 public static Date getparseDate(String strDate) throws ParseException{
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    return sdf.parse(strDate);
 }

  
}
