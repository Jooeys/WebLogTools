﻿package com.tjpu.util;

import java.io.FileWriter;
import java.io.File;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
/*文件工具类*/
public class FileHelp {
	public static  int  writeToFile(String filename,String content ) {
           	int ret=0;
           	try {
				FileWriter fw;
				
				//fw= new FileWriter(filename, true);
				File file = new File(filename);
				if (!file.exists() || !file.isFile() ) {
				  file.createNewFile();	
				}
				
				fw= new FileWriter( file,true);
			    fw.write(content);
			    fw.close();
			    ret=1;
           	} 
           	catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           	
           	return ret;
	}
	/*读取属性文件*/
	 public  String  getProperty(String pro_name,String key) {   
	     String str_value="";
		 Properties props = new Properties();   
	    
	     try {   
	    // 资源文件存放在类文件的根目录下。即是放在src下面。   
	    props.load(getClass().getClassLoader().getResourceAsStream(   
	    		pro_name+".properties"));   
	    str_value=new String(props.getProperty(key).getBytes(   
    "ISO-8859-1"), "GBK");   
	     } catch (UnsupportedEncodingException e) {   
	   e.printStackTrace();   
	     } catch (IOException e) {   
	     e.printStackTrace();   
	    } 
	    return str_value;
	  }   

}
