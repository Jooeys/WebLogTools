package com.tjpu.util;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

public class connMySql {

	public static void main(String[] args) throws FileNotFoundException, ParseException, SQLException {
		// TODO Auto-generated method stub
        //File file = new File("Log.txt");
        
       // FileOutputStream fos=new FileOutputStream("c:\\11.txt");  
       // BufferedWriter bw=new BufferedWriter(fos);  
       // bw.write("���");  
       // bw.newline();  
       // bw.write("java");  
       // bw.newline();   

        int i,j;
        int ret = 0;
		String str="";
        //Date p_date=Calendar.getInstance().getTime();
		Date p_date = Calendar.getInstance().getTime();
        Common com = new Common();
        
        
        
        Connection mycon = null;
		try {
			mycon = DBHelp.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String start = com.getCurrentDate();
       
        for(j=0;j<10000;j++){
        	String ip_address = "";
        for(i=0;i<4;i++)
        {
        	if(i < 3)
        	ip_address = ip_address + com.getRand(255) + ".";
        	else ip_address = ip_address + com.getRand(255);
        }

        String access_time=com.getCurrentDate();
        int access_count=com.getRand(100);
        
		String p_sql="insert into Log_20170622 (ip_address,access_time,access_count) values(";
		p_sql = p_sql+"'"+ip_address+"',";
		p_sql = p_sql+"'"+access_time+"',";
		p_sql = p_sql+access_count+")";
		ret=DBHelp.executeSQl(p_sql);
		
        }
        System.out.println("开始时间" + start);
		System.out.println("结束时间" + com.getCurrentDate());
		DBHelp.Close(mycon, null, null);
		//����SQL
		if (ret>0) {
			 System.out.println("����ɹ�");		
			} else {
				 System.out.println("����ʧ��");		
						
			}
		
	}

}
