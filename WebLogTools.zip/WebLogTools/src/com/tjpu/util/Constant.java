package com.tjpu.util;

public class Constant {
   public static final String DB_NAME="";
   public static final int PORT=3306;
   
}
