package com.tjpu.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import com.tjpu.dao.WeblogDao;
import com.tjpu.util.*;


public class WebLogTest {

	public static void main(String[] args) throws FileNotFoundException, ParseException, SQLException {
		// TODO Auto-generated method stub
       		//int ret=WeblogDao.makeRandDataToDb();
		int ret=0;
		//System.out.println("开始时间："+Common.getCurrentDate());
		String begin_time=Common.getCurrentDate();
		System.out.println("----------------------");
		/*写入一万次*/
		for (int i = 0; i < 1000; i++) {
			// ret=WeblogDao.makeRandDataToFile(i+1);
			
			ret=WeblogDao.makeRandDataToDb();
			 
			if (ret>0) {
			    System.out.println("第"+(i+1)+"次写入成功");		
			} else {
				 System.out.println("第"+(i+1)+"次写入失败");		
						
			}
		
		}
		System.out.println("开始时间："+begin_time);
		System.out.println("结束时间："+Common.getCurrentDate());
	}

}
